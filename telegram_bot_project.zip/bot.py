
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

TOKEN = os.getenv("BOTTOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("أرسل /created داخل أي جروب علشان أقولك تاريخ أول رسالة فيه.")

async def created(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    first_date = None
    async for msg in context.bot.get_chat_history(chat.id, limit=1, reverse=True):
        first_date = msg.date.strftime("%Y-%m-%d %H:%M:%S")
    if first_date:
        await update.message.reply_text(f"أول رسالة في الجروب كانت بتاريخ: {first_date}")
    else:
        await update.message.reply_text("مش قادر أوصل لأول رسالة. لازم أكون أدمن والجروب يسمح بمشاهدة الرسائل القديمة.")

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("created", created))
    app.run_polling()

if __name__ == "__main__":
    main()
